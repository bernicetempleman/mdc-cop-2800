/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package futurevalue.ui;

/**
 *
 * @author Bernice.Templeman001
 */
import javax.swing.JOptionPane;
import javax.swing.text.JTextComponent;

/**
 *
 * @author azejnilo
 */
public class SwingValidator {
    public boolean isPresent(JTextComponent c, String fieldName)
    {
       if(c.getText().length() == 0)
        {
            String message = fieldName + " is a required field";
            String title  = "Invalid Entry";
            JOptionPane.showMessageDialog(c, message, title, 
                    JOptionPane.ERROR_MESSAGE);
        } 
       
       return true;
    }
}

