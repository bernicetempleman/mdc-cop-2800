/*
 * Programmer : Bernice Templeman
 * COP2800
 * Exercise 3: Ships
 *
 * Description:
 *
 * Demonstrate the classes in a test program that has a Ship ArrayList. 
 * Assign various Ship, CruiseShip, and CargoShip objects to the array list elements. 
 * The program should then loop through the ArrayList, 
 * calling each object’s toString method.
* 
 */

package ex03.templemanb;

import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author bernice.templeman001
 */
public class Ex03TemplemanBTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Ship ArrayList.

        ArrayList<Ship> ShipList = new ArrayList<Ship>();

        // Assign various Ship, CruiseShip, and CargoShip objects to the array list elements.
        ShipList.add ( new Ship("First", "2014"));
        ShipList.add ( new CruiseShip(2000, "Second","2013"));
        ShipList.add ( new CargoShip(5000, "Third","2012"));
        ShipList.add ( new CargoShip(10000, "Fourth", "2011"));
        ShipList.add ( new CruiseShip(1000, "Fifth", "2010"));
        
        //loop through the ArrayList, 
        for (Ship s: ShipList)
        {
            //calling each object’s toString method.
            System.out.println(s.toString());
        }
        
    }

}
