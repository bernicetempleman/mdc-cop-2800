/*
 * Programmer : Bernice Templeman
 * COP2800
 * Exercise 3: Ships
 * Description:
 *
 * Design a Ship class that the following members:
 * A field for the name of the ship (a string).
 * A field for the year that the ship was built (a string).
 *  A constructor and appropriate accessors and mutators.
 *  A toString method that displays the ship’s name and the year it was built.
*/

package ex03.templemanb;

/**
 *
 * @author bernice.templeman001
 */
public class Ship {

    // A member variable for the name of the ship (a string)
    public String name;

    // A member variable for the year that the ship was built (a string)
    public String yearBuilt;

    // Constructor
    public Ship(String name, String yearBuilt) {
        this.name = name;
        this.yearBuilt = yearBuilt;
    }

    // accessors and mutators
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYearBuilt() {
        return yearBuilt;
    }

    public void setYearBuilt(String yearBuilt) {
        this.yearBuilt = yearBuilt;
    }

    //A toString method override that displays the ship’s name and the year it was built.
    @Override
    public String toString()
    {
        String output =("Name: " 
                        + this.name 
                        + "  Year Built: "
                        + this.yearBuilt);
        return output;
    }

}
