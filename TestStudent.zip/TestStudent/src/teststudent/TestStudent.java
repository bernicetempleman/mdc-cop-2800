/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package teststudent;

import java.util.Scanner;

/**
 *
 * @author Renzo
 */
public class TestStudent {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here      
        Scanner input = new Scanner(System.in);
        
        StudentGpa studentInfo = new StudentGpa();
        
        System.out.println("Enter your Name: ");
        String name = input.nextLine();
        System.out.println("Enter your Age: ");
        int age = input.nextInt();
        System.out.println("Enter your Major: ");
        String major = input.next();
        System.out.println("Enter Test 1: ");
        int test1 = input.nextInt();
        System.out.println("Enter Test 2: ");
        int test2 = input.nextInt();
        System.out.println("Enter Test 3: ");
        int test3 = input.nextInt();
        
        studentInfo.setName(name);
        studentInfo.setAge(age);
        studentInfo.setMajor(major);
        studentInfo.setGpa(' ', test1, test2, test3);
        //studentInfo.setLetterGrade(letterGrade)      
        
        studentInfo.display();
         
        /*System.out.printf("Name: %s\n ", studentInfo.getName());
        System.out.printf("Age: %d\n ", studentInfo.getAge());
        System.out.printf("Major: %s\n", studentInfo.getMajor());
        System.out.printf("GPA: %.2f\n ", studentInfo.getGpa()); 
        System.out.printf("Letter Grade: %c\n ", studentInfo.getLetterGrade());*/
        
    }
    
}
