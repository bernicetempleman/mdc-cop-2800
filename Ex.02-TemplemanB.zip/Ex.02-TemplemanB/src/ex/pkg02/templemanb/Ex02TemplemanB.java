/* Programmer : Bernice Templeman
 * COP2800
 * Exercise 2 : Theater Seating Chart
 * 
 * Description:
 * A theater seating chart is implemented as a two dimensional array of ticket prices
 *
 * Write a program that presents a menu allowing users to pick either a seat or a price:
 * Welcome to the COP2800 Theater!
 * Please select one of the following:
 * 1) Buy a specific seat
 * 2) By any seat by price
 * 3) View available seats
 * Your Choice:
 *
 * Mark sold seats by changing the price to 0. 
 * When a user specifies a seat, make sure it is available. 
 * When a user specifies a price, find any seat with that price.
 * 
 * Create a class and a driver program.
 */
package ex.pkg02.templemanb;

import java.util.Scanner;

/**
 *
 * @author bernicetempleman
 */
public class Ex02TemplemanB {

    /**
     * @param args the command line arguments
     */
  
public static void main(String[] args) {
    
        //variables:
        String choice;              //holds user choice
        String seatRow;             //variable to get user input for row
        int seatRowInt;             //holds interger value of user row 
        String seatNumber;          //variable to get user input for seat
        int seatNumberInt;          //holds interger value of user seat
        int foundSeat = 0;          // flag for found seat seat to false
        String price;               // price user enters
        int priceInt;               // interger price
        boolean parsable = true;    // flag to check for parsable input price
        boolean parsablerow;        //flag to check for parsable row input
    
        //theater seating chart array
        int [][] seats = {
                           {10, 10, 10, 10, 10, 10, 10, 10, 10, 10},
                           {10, 10, 10, 10, 10, 10, 10, 10, 10, 10},
                           {10, 10, 10, 10, 10, 10, 10, 10, 10, 10},
                           {10, 10, 20, 20, 20, 20, 20, 20, 10, 10},
                           {10, 10, 20, 20, 20, 20, 20, 20, 10, 10},
                           {10, 10, 20, 20, 20, 20, 20, 20, 10, 10},
                           {20, 20, 30, 30, 40, 40, 30, 30, 20, 20},
                           {20, 30, 30, 40, 50, 50, 40, 30, 30, 20},
                           {30, 40, 50, 50, 50, 50, 50, 50, 40, 30}         
                         };
   
        SeatingChart seating = new SeatingChart(seats);
        
        //present menu
        displayMenu();
        
        //get user choice
        Scanner userInput = new Scanner(System.in);
        choice = userInput.next();

        switch (choice) 
        {
                case "1": // Buy a specific seat

                        // ask for seat row (0-8)
                        System.out.printf("Enter seat row (0-8): ");
        
                        //get seat row from user    
                        seatRow = userInput.next();
        
                        //check if user entered an integer
                        //set flag parsablerow to true
                        parsablerow = true;
                        try 
                        { 
                            Integer.parseInt( seatRow );
                        }
                        //if not parsable set flag to false
                        catch (NumberFormatException e)
                        {
                          parsablerow = false;
                          //display error message
                          System.out.println("Invalid Row Number. \n");
                        }
        
                       //if parsable row number
                       if (parsablerow)
                       {          
                            //convert STRING TO INT
                            seatRowInt = Integer.parseInt(seatRow);
                            System.out.println(seatRowInt);

                            //check for correct input (row 0-8)
                            if ((seatRowInt < 0) || (seatRowInt >8))
                            {
                                System.out.println("Invalid Row Number. \n");
                            }
                            else // row number valid
                            {
                                // ask for seat number in row (0-9)
                                System.out.printf("Enter seat number in row (0-9): ");
        
                                //get seatNumber
                                seatNumber = userInput.next();

                                //check if parsable input
                                parsable = true;
                                try 
                                { 
                                    Integer.parseInt( seatNumber );
                                }
                                catch (NumberFormatException e)
                                {
                                    parsable = false;
                                    System.out.println("Invalid Seat Number. \n");
                                }
                                if (parsable)//if valid seat numer
                                {   
                                    // convert string to int
                                    seatNumberInt = Integer.parseInt(seatNumber);
                                    System.out.println(seatNumber);
            
                                    //check for correct input for seat number(numer 0-9)
                                    if ((seatNumberInt < 0) || (seatNumberInt >9))
                                    {
                                        System.out.println("Invalid Seat Number. \n");
                                    }
                                    else // else seat number valid
                                    {
                                        //call BuySeat
                                        seating.BuySeat(seats, seatRowInt,seatNumberInt);
                                    }//end else valid seat
                                }// end if parsable
                            }//end else valid row
                        }//end if parsable row
                        break;
                    
                case "2": // Buy any seat by price
     
                        // ask for price
                        System.out.printf("Enter a price: ");
        
                        //get price
                        price = userInput.next();

                        //check for correct input
                        // price is numeric     
                        parsable = true;
                        try 
                        { 
                            Integer.parseInt( price );
                        }
                        catch (NumberFormatException e)
                        {
                            parsable = false;
                            System.out.println("Invalid Seat Price. \n");
                        }
        
                        if (parsable)
                        {
                            //if valid price....buy any seat
                            //convert string to int
                            priceInt = Integer.parseInt(price);
                            System.out.println(priceInt);
        
                            //check for correct input
                            // price >0
                            if ( priceInt >0)
                            {      
                                seating.buySeatByPrice(seats,priceInt);
                            }
                            else
                            {
                                System.out.println("Invalid Price.");
                            }
                        } 
                        break;
                        
                case "3": // View available seats
                        System.out.println("Available Seats:");
                        seating.displayAvailableSeats(seats);
                        break;
                        
                default: //Invalid choice
                        System.out.println("Invalid Choice");
                        break;
        }//end switch
       
    }//end main

    public static void displayMenu()
    {
        System.out.println("\nWelcome to the COP2800 Theater!\n" +
                           "Please select one of the following:\n" +
                           "1) Buy a specific seat\n" +
                           "2) Buy any seat by price\n" +
                           "3) View available seats\n" +
                           "Your Choice: ");
    }
}

