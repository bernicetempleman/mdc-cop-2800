/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testemployee;

/**
 *
 * @author Renzo, Bernice, Lindy
 */
public class employee {
    
    String employeeName;
    int employeeId;
    double employeeSalary;
    
    public employee(String employeeName, int employeeId, double employeeSalary)
    {
        this.employeeName = employeeName;
        this.employeeId = employeeId;
        this.employeeSalary = employeeSalary;
    }
    
    public String getName() {
        return employeeName;
    }

    public void setName(String name) {
        this.employeeName = name;
    }
    
    public int getId() {
        return employeeId;
    }

    public void setId(int id) {
        this.employeeId = id;
    }
    
    public double getSalary() {
        return employeeSalary;
    }

    public void setSalary(double salary) {
        this.employeeSalary = salary;
    }
    
    public void updateSalary(double pct)
    {
        employeeSalary = (employeeSalary * pct) + employeeSalary;
    }
    
    public void display()
    {
        System.out.printf("Employee Name: %s\n ", getName());
        System.out.printf("Employee Id:  %d\n ", getId());
        System.out.printf("Employee Salary: %.2f\n", getSalary());
       // System.out.println("Employee Salary Increase: %.2f\n", updateSalary());
    }
    
}
