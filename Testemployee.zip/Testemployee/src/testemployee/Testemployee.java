/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testemployee;

/**
 *
 * @author Renzo, Bernice, Lindy
 */
public class Testemployee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //employee newemployee = new employee();
         employee employee1 = new employee("Luis", 2014, 50000);
         employee employee2 = new employee("Joe", 2010, 30000);
         
         
         
         employee1.display();
         employee2.display();
         //
         final double pctIncerse1 = 0.15;
         
         employee1.updateSalary(pctIncerse1);
         employee2.updateSalary(pctIncerse1);
         
         System.out.println("\nAfter Salary Increase:");
         employee1.display();
         employee2.display();

         
         
         
    }
    
}
