/*
 * Programmer : Bernice Templeman
 * COP2800
 * Exercise 3: Ships
 *
 * Design a CruiseShip class that extends the Ship class.
 *
 * The CruiseShip class should have the following members:
 * A field for the maximum number of passengers ( an int ).
 * A constructor and appropriate accessors and mutators.
 * A toString method that overrides the toString method in the base class. 
 * The CruiseShip class’s toString method 
 * should display only the ship’s name and the maximum number of passengers.
 *
 * CruiseShip Class
 * CruiseShip Class is derived from the Ship Class
 * 
 * The CruiseShip class has the following members:
 * A member variable for the maximum number of passengers (an int)
 * A constructor and appropriate accessors and mutators
 * A toString method that overrides the toString method in the base class. 
 * The CruiseShip class’s toString method should 
 *  only the ship’s name and the maximum number of passengers. 

 */

/**
 *
 * @author bernice.templeman001
 */

package ex03.templemanb;


import ex03.templemanb.Ship;


public class CruiseShip extends Ship{

    //A field for the maximum number of passengers ( an int )
    private int maxPassengers;

    // Constructor 
    public CruiseShip(int maxPassengers, String name, String yearBuilt) {
        super(name, yearBuilt);
        this.maxPassengers = maxPassengers;
    }

    //ccessors and mutators
    public int getMaxPassengers() {
        return maxPassengers;
    }

    public void setMaxPassengers(int maxPassengers) {
        this.maxPassengers = maxPassengers;
    }
    
    //A toString method that overrides the toString method in the base class.
    @Override
    public String toString()
    {
        //display only the ship’s name and the maximum number of passengers.
        String output =("Name: " 
                         + this.name 
                         + "  Maximum Number of Passengers: "
                         + this.maxPassengers);
        return output;

                            
    }


}
