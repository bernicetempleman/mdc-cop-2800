/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sc01.animalfarmproject;

import java.util.ArrayList;

/**
 *
 * @author roicxy.alonso001 ; bernice.templeman001
 */
public class SC01AnimalFarmProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Animal[] AnimalFarm = new Animal[8];
       AnimalFarm[0] = new Horse();
       AnimalFarm[1] = new Horse();
       AnimalFarm[2] = new Dog();
       AnimalFarm[3] = new Cat();
       AnimalFarm[4] = new Pig();
       AnimalFarm[5] = new Pig();
       AnimalFarm[6] = new Duck();
       AnimalFarm[7] = new Duck();
       
       
        for (Animal p : AnimalFarm)
        {
            p.speak();
        }
    }
    
}
