/*
 * Bernice Templeman
 * Oct 1, 2014
 * ICW: ask for positive numbers , -99 to quit
 * display largest & smallest
 */

package icw.large.small.number;

import java.util.Scanner;

/**
 *
 * @author bernice.templeman001
 */
public class ICWLargeSmallNumber {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        final int SENTINEL = -99;
        int number;
        int largest;
        int smallest;
        
        //ask for largest
        System.out.println("Enter a positive number or -99 to quit: ");
        
        Scanner userInput = new Scanner(System.in);
        number = userInput.nextInt();
        
        //check if not -99
        if (number == SENTINEL)
        {
            System.out.println("thank you");
        }
        else
        {
            largest = number;
            smallest = number;
            while(number != SENTINEL)
             {
                
                 System.out.println("Enter a positive number or -99 to quit: ");
                  number = userInput.nextInt();
                   if (number != SENTINEL)
                    {
                   
                     if (largest < number)
                         largest = number;
                     if (smallest > number)
                        smallest = number;
                   }
             }
            System.out.println("largest = " + largest);
            System.out.println("smallest = " +smallest);
        
          }
        // TODO code application logic here
    }
    
}
