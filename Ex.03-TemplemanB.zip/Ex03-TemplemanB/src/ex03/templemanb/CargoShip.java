/*
 * Programmer : Bernice Templeman
 * COP2800
 * Exercise 3: Ships
 *
 * Description:
 * Design a CargoShip class that extends the Ship class. 
 *
 * The CargoShip class should have the following members:
 * A field for the cargo capacity in tonnage (an int)
 * A constructor and appropriate accessors and mutators.
 * A toString method that overrides the toString method in the base class. 
 * The CargoShip class’s toString method should 
 * display only the ship’s name and the ship’s cargo capacity.
 */

/**
 *
 * @author bernice.templeman001
 */

package ex03.templemanb;


import ex03.templemanb.Ship;

public class CargoShip extends Ship{

    // A member variable for the cargo capacity in tonnage (an int)
    private int cargoCapacityTon;

    // constructor 

    public CargoShip(int cargoCapacityTon, String name, String yearBuilt) {
        super(name, yearBuilt);
        this.cargoCapacityTon = cargoCapacityTon;
    }

    //accessors and mutators.
    public int getCargoCapacityTon() {
        return cargoCapacityTon;
    }

    public void setCargoCapacityTon(int cargoCapacityTon) {
        this.cargoCapacityTon = cargoCapacityTon;
    }
    
    // A toString method that overrides the toString method in the base class. 
    @Override
    public String toString()
    {
        // display only the ship’s name and the ship’s cargo capacity.
        String output =("Name: " 
                        + this.name 
                        + "  Cargo Capacity: "
                        + this.cargoCapacityTon);
        return output;
    }

}
