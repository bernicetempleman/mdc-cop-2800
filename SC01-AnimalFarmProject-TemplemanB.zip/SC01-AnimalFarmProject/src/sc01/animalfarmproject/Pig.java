/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sc01.animalfarmproject;

/**
 *
 * @author roicxy.alonso001
 */
public class Pig extends Animal {
    
    @Override
    public void speak()
    {
        System.out.println("Pig: oinks");
    }
    
}
