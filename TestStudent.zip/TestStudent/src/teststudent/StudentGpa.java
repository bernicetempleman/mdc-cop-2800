/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package teststudent;

/**
 *
 * @author Renzo
 */
public class StudentGpa {
    
    private String name;
    private int age;
    private String major;
    private int test1, test2, test3;
    private double gpa;
    private char letterGrade;
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
    public String getMajor() {
        return major;
    }
    
    public void setMajor(String major){
        this.major = major;
    }
    
    public double getGpa(){
        gpa = (test1 + test2 + test3)/3.0;
        return gpa;
    }
    
    public void setGpa(double gpa, int test1, int test2, int test3){
        this.gpa = gpa;
    }
    
    public char getLetterGrade(){
        if (gpa < 60)
            letterGrade = 'F';
        else if (gpa < 70)
            letterGrade = 'D';
        else if (gpa < 80)
            letterGrade = 'C';
        else if (gpa < 90)
            letterGrade = 'B';
        else if (gpa <= 100)
            letterGrade = 'A';
        return letterGrade;
    }
    
    public void setLetterGrade(char letterGrade){
        this.letterGrade = letterGrade;
    }
    
    public void display()
    {
        System.out.printf("Name: %s\n ", getName());
        System.out.printf("Age:  %d\n ", getAge());
        System.out.printf("Major: %s\n", getMajor());
        System.out.printf("GPA: %.2f\n", getGpa());
        System.out.printf("Letter Grade: %c\n ", getLetterGrade());
    }
}
