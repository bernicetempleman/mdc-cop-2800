/*
 * Programmer : Bernice Templeman
 * COP2800
 * Exercise 2 : Theater Seating Chart
 */
package ex.pkg02.templemanb;

import java.util.Scanner;

/**
 *
 * @author bernicetempleman
 */
public class SeatingChart {
    
    //Constructor
    public SeatingChart( int[][] seats) {
    }

    //dispalySeats
    public static void displaySeats(int[][]seatingChart) {
        for(int curRow = 0; curRow < seatingChart.length; curRow++ )
        { 
            for (int curCol=0; curCol < seatingChart[curRow].length; curCol++)
            {
                System.out.printf("%3d", seatingChart[curRow][curCol]);
            }
            
            System.out.println(" ");
        }
    } // ens displaySeats

    //Buy a specific seat    
    public static void BuySeat(int[][]seatingChart, int seatRowInt, int seatNumberInt)
    {

        //check if not available == 0)
         if (seatingChart[seatRowInt][seatNumberInt] == 0)
         {
            System.out.printf("Seat is unavailable ");
         }//end if not available

         else //seat available
        { 
            //Display seat available & price
            System.out.printf("Seat is available. Sold at price:  ");
            System.out.printf( "%5d \n",seatingChart[seatRowInt][seatNumberInt]);
            
            // update to seat to sold
            seatingChart[seatRowInt][seatNumberInt] = 0;
                     
        }//end else seat available       
     }// END ELse  seat number valid          

    //buy any seat by price  
    public static void buySeatByPrice(int[][]seatingChart, int priceInt)
    {
        //variable declarations
        int foundSeat = 0;        // flag for found seat seat to false
           
        //search for seat by price
        for(int curRow = 0; ((foundSeat!=1) &&(curRow < seatingChart.length) ); curRow++ )
        {
            for (int curCol=0; ((foundSeat!=1) && (curCol < seatingChart[curRow].length)); curCol++)
            {
                if (priceInt == seatingChart[curRow][curCol])
                {
                    System.out.printf("Sold Seat at price $: ");
                    System.out.printf("%3d : row = %3d seat = %3d", seatingChart[curRow][curCol], curRow, curCol);

                    //update seat to sold
                    seatingChart[curRow][curCol] = 0;
                   
                    //update foundSeat to end search
                    foundSeat = 1;
                 }//end if found seat
            }//end for COl
                           
            System.out.println(" ");
        }//end for row
             
            //if no seat found display message     
        if(foundSeat == 0)
        {
            System.out.println("There are seats at that price.");
        } //end if no seat
    }//end 
    
    //view available seats    
    public static void displayAvailableSeats(int[][]seatingChart)
    {
	System.out.printf("(Seats marked with 0 are not available)\n");
        
        for(int curRow = 0; curRow < seatingChart.length; curRow++ )
        {
            for (int curCol=0; curCol < seatingChart[curRow].length; curCol++)
            {
		if (seatingChart[curRow][curCol] != 0)
                {
                    System.out.printf("%3d", seatingChart[curRow][curCol]);
                }//end if
            }//end for col
            
            System.out.println(" ");
        }//end for row
    }//end displayAvailableSeats
}